# Primitive Crafting

**Minecraft:** Java 1.21.1  
**Loader:** NeoForge 21.1.x  
**Mod ID:** `primitivecrafting`  
**Version:** 1.0.0

Primitive Crafting makes tool recipes more demanding and includes a rustic crafting-board texture concept plus a separate resource-pack folder.

## Recipe changes
The mod overrides selected vanilla recipes: wooden, stone, iron, golden, and diamond swords, pickaxes, axes, shovels, and hoes, plus shears, bow, fishing rod, and shield. These recipes require string as binding material.

## Resource pack
The `resourcepack/` folder can be zipped and placed in `.minecraft/resourcepacks`. It includes a rustic board texture reference. **Important:** the included texture is not yet wired into vanilla's crafting screen. Minecraft 1.21.1 does not provide a single simple crafting-table GUI background texture to replace; a custom NeoForge screen renderer is needed for the new table UI to actually appear in-game.

## Build
1. Install JDK 21.
2. Use Gradle 8.10+ or import the project in IntelliJ IDEA.
3. Run `gradle build` from the project folder, or use the included GitHub Actions build workflow in the companion build-kit ZIP.
4. Find the output JAR in `build/libs/`.
5. Put it in `.minecraft/mods` under NeoForge 1.21.1.

This source project has not been compiled or tested in a Minecraft runtime in this environment.


## Important limitation
This project has not been compiled or tested here. It currently overrides selected vanilla recipes and includes a texture concept; it does not yet implement a custom crafting-table block or GUI.
