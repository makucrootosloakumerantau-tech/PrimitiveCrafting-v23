Primitive Crafting Resource Pack
Minecraft Java 1.21.1

This pack includes a rustic crafting-board texture concept at:
assets/minecraft/textures/gui/primitive_crafting_board.png

Note: vanilla Minecraft 1.21.1's crafting screen is rendered by GUI code and does not expose one single full-screen crafting-table background texture that a pack can simply replace. This texture is included as a visual asset, but the mod must render it in a custom screen to make it appear in-game. The current mod source includes the texture and recipe overrides; custom screen integration is a follow-up implementation step.
