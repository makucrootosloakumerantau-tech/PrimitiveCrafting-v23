package com.example.primitivecrafting;

import net.neoforged.fml.common.Mod;

@Mod(PrimitiveCrafting.MOD_ID)
public final class PrimitiveCrafting {
    public static final String MOD_ID = "primitivecrafting";

    public PrimitiveCrafting() {
        // Recipes and resource-pack assets are provided by bundled data/resources.
    }
}
